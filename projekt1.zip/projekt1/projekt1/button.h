#pragma once
struct button 
{
	int id;
	char tab[5];
	char id2;
	int len;

};